package com.example.jsonfile;

import android.app.Activity;
import android.content.res.AssetManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;

public class MainActivity extends Activity implements View.OnClickListener {
    Button btnjson;
    TextView txtresult;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnjson=findViewById(R.id.btn_parse);
        btnjson.setOnClickListener(this);
        txtresult=findViewById(R.id.txt_res);
    }
    public void onClick(View v){
        try {
            InputStream is=getAssets().open("example.json");
            int size=is.available();
            byte[] buffer=new byte[size];
            is.read(buffer);
            is.close();
            String json=new String(buffer,"UTF-8");
            JSONArray obj=new JSONArray(json);
            txtresult.setText("");
            for(int i=0;i<obj.length();i++){
                JSONObject ob1=obj.getJSONObject(i);
                String s1=ob1.getString("name");
                String s2=ob1.getString("latitude");
                String s3=ob1.getString("longitude");
                String s4=ob1.getString("temperature");
                txtresult.setText(txtresult.getText()+"\nName:"+s1+"\nLatitude:"+s2+"\nLongitude:"+s3+"\nTemperature:"+s4+"\n");
            }
        }
        catch (Exception e){
        }
    }
}