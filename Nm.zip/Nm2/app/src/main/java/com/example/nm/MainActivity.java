package com.example.nm;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.view.View;
import android.os.Bundle;
import android.widget.Button;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{
    Button start,stop;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        start=(Button) findViewById(R.id.btn_start);
        start.setOnClickListener(this);
        stop=(Button) findViewById(R.id.btn_stop);
        stop.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if(v.equals(start)){
            Intent it=new Intent(this, ServiceClass.class);
            startService(it);
        }
        else if(v.equals(stop)){
            Intent it=new Intent(this, ServiceClass.class);
            stopService(it);
        }
    }
}

