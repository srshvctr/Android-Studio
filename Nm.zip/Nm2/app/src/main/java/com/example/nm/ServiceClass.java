package com.example.nm;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

public class ServiceClass extends Service {
    boolean running = false;
    Mythread thread;

    public void onCreate() {
        super.onCreate();
        Toast.makeText(getBaseContext(), "service created", Toast.LENGTH_LONG).show();
        running = true;
        thread = new Mythread();
        thread.start();
    }

    public int onStartCommand(Intent intent, int flag, int startid) {
        super.onStartCommand(intent, flag, startid);
        Toast.makeText(getBaseContext(), "service started", Toast.LENGTH_LONG).show();
        if (!thread.isAlive()) {
            thread = new Mythread();
            thread.start();
        }
        return Service.START_NOT_STICKY;

    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    public void onDestroy() {
        running = false;
        Toast.makeText(getBaseContext(), "service stopped", Toast.LENGTH_LONG).show();
        super.onDestroy();
    }

    Handler hand = new Handler() {
        public void handleMessage(Message m) {
            NotificationManager man = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            NotificationCompat.Builder builder= new NotificationCompat.Builder(getBaseContext());
            builder.setContentTitle("from service");
            builder.setContentText("Hi Suresh S "+m.what);
            builder.setContentIntent(PendingIntent.getActivity(getBaseContext(),1,new Intent(getBaseContext(), MainActivity.class), Intent.FILL_IN_ACTION));
            Notification nof=builder.build();
            man.notify(100,nof);
        }
    };
    class Mythread extends Thread
    {
        public void run()
        {
            int i=0;
            while(running)
            {
                try{
                    Thread.sleep(1000);
                }catch(InterruptedException e){
                    e.printStackTrace();
                }
                hand.sendEmptyMessage(i++);
            }
        }
    }
}

